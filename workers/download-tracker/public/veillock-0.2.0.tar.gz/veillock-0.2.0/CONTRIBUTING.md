# Contributing to VeilLock

**Forks are first-class.** This project is Apache-2.0; you do not need
permission to fork, patch, or redistribute. Pull requests are welcome
if you want a change upstream. Keep a fork forever if you do not.

**Forks are welcome and always allowed.**

## How to run tests

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest -q
```

Python 3.10+, numpy, cryptography, pytest. No hardware. Fixtures in
`tests/conftest.py` are synthetic RGB frames (16×16 and 64×64).

## Ground rules

1. Treat `origin` as one peer among many. Downstream forks are part of
   the download-tracking model (see `workers/download-tracker`): they
   report as `{owner}/{repo}`, not as anonymous noise.
2. **Do not invent evaluation numbers or fake latency measurements.**
   The whitepaper states a *target* of &lt;1 ms/frame for small frames.
   If you measure something, publish the machine, the frame size, and
   the method in the same breath as the number.
3. **Do not implement malware, screen scrapers, or exploits.** VeilLock
   is consent-gated camera protection via AZ-OS: frames the caller
   already holds, veiled by default. Capture of another process’s
   screen is out of scope. Keep the user in control of the veil.
4. **Keep the dependency list small.** numpy + cryptography in the core
   CLI. Optional dev extra is pytest. Optional tether extra is
   opencv-python-headless + pyvirtualcam (never add those to core).
5. **Forward secrecy is not optional.** Rotation must drop old session
   keys. Do not cache epoch keys “for convenience.”
6. **Do not gut crypto to make a test pass.** If a threshold is too
   tight (for example decoy entropy), loosen the test.

## Where to change things

- Session / encrypt / decrypt: `veillock/engine.py`
- KDF, AES-GCM, wrap, ratchet: `veillock/crypto.py`
- PulseCheck / HaltedError: `veillock/pulse.py`
- Phoenix Loop: `veillock/phoenix.py`
- Metadata scrub: `veillock/metadata.py`
- Modes, natural camera veil, decoy frames: `veillock/modes.py`
- AZ-OS consent hook: `veillock/azos.py`
- Camera / screen tether: `veillock/sources.py`, `veillock/tether.py`
- New behavior needs a synthetic test that fails without the change.
  Tether tests mock VideoCapture and pyvirtualcam; no camera required.

## Reporting downloads from a fork

Point users at GitHub Releases. If you cut your own releases, POST
`/event` on the download-tracker worker so counts stay attributed to
your `owner/repo` (see `workers/download-tracker/README.md`).

## License of contributions

By submitting a change you agree it is licensed under Apache-2.0, the
same license as the rest of the tree. Keep the copyright lines honest.
